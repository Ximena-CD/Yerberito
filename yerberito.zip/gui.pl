% Cargar la biblioteca XPCE para la GUI
:- use_module(library(pce)).

% Cargar los archivos de conocimiento y consultas
:- consult('bdplantas.pl').
:- consult('consultas_plantas.pl').

% Predicado principal para iniciar la GUI
mostrar_gui :-
    new(Dialog, dialog('Informaci�n de Plantas')),
    send(Dialog, size, size(1000, 750)),

    % Men� desplegable para seleccionar planta
    new(MenuPlanta, menu('Selecciona una Planta', cycle)),
    send(Dialog, append, MenuPlanta),

    findall(Especie, nombre_cientifico(Especie, _), Especies),
    sort(Especies, EspeciesUnicas),
    forall(member(Especie, EspeciesUnicas),
           send(MenuPlanta, append, Especie)),

    % �rea de texto para mostrar resultados
    new(Text, editor),
    send(Text, editable, @off),
    send(Text, size, size(500, 400)),

    % �rea para mostrar imagen
    new(ImageBox, picture),
    send(ImageBox, size, size(200, 200)),

    % Agrupar imagen y texto
    new(Horizontally, dialog_group(horizontal)),
    send(Horizontally, append, ImageBox),
    send(Horizontally, append, Text),
    send(Dialog, append, Horizontally),

    % Acci�n al seleccionar planta
    send(MenuPlanta, message, message(@prolog, mostrar_info_planta, MenuPlanta?selection, Text, ImageBox)),

    % Campo para escribir par�metro (planta, enfermedad, medicamento)
    new(InputField, text_item('Par�metro (si aplica)')),
    send(Dialog, append, InputField),

    % Men� desplegable de consultas generales
    new(ConsultasMenu, menu('Consulta general', cycle)),
    Consultas = [
        'Plantas medicinales',
        'Elementos en plantas',
        'Elementos de una planta',
        'Plantas que producen medicamentos',
        'Medicamentos de una planta',
        'Medicamentos de plantas',
        'Efectos de medicamentos de plantas',
        'Efectos de un medicamento',
        'Acciones o efectos de plantas',
        'Significado de acci�n o efecto',
        'Plantas y sus acciones/efectos',
        'Acciones de una planta',
        'Plantas analg�sicas',
        'Plantas y nombres cient�ficos',
        'Enfermedades tratadas por plantas',
        'Enfermedades tratadas por una planta',
        'Plantas que tratan una enfermedad',
        'Formas de preparaci�n',
        'Preparaci�n de una planta',
        'Tratamiento para una enfermedad',
        'Origen de plantas',
        'Origen de una planta',
        'Tratamiento general para enfermedad',
        'Botiqu�n de plantas'
    ],
    forall(member(C, Consultas), send(ConsultasMenu, append, C)),
    send(Dialog, append, ConsultasMenu),

    % Bot�n para ejecutar consulta
    send(Dialog, append, button('Ejecutar Consulta',
        message(@prolog, ejecutar_consulta_general,
                ConsultasMenu?selection,
                InputField?selection,
                Text))),

    % Mostrar ventana
    send(Dialog, open).

% Mostrar informaci�n y cargar imagen de planta
mostrar_info_planta(Especie, Text, ImageBox) :-
    findall(Info, info_planta(Especie, Info), InfoList),
    atomic_list_concat(InfoList, '\n', InfoText),
    send(Text, contents, InfoText),
    send(ImageBox, clear),
    atom_concat('imagenes/', Especie, RutaBase),
    atom_concat(RutaBase, '.jpg', RutaImagen),
    ( exists_file(RutaImagen) ->
        new(Image, image(RutaImagen)),
        new(Bitmap, bitmap(Image)),
        new(Box, box(210,210)),
        send(Box, fill_pattern, Bitmap),
        send(ImageBox, display, Box, point(0,0))
    ;
        send(ImageBox, display, text('Imagen no disponible'))
    ).

% Recolectar informaci�n desde hechos
info_planta(Especie, Info) :- nombre_cientifico(Especie, Nombre), format(atom(Info), 'Nombre Cient�fico: ~w (~w)', [Especie, Nombre]).
info_planta(Especie, Info) :- continente_origen(Especie, Continente), format(atom(Info), 'Continente de Origen: ~w', [Continente]).
info_planta(Especie, Info) :- pais_origen(Especie, Pais), format(atom(Info), 'Pa�s de Origen: ~w', [Pais]).
info_planta(Especie, Info) :- modo_preparacion(Especie, Modo), format(atom(Info), 'Modo de Preparaci�n: ~w', [Modo]).
info_planta(Especie, Info) :- trata_enfermedad(Especie, Enfermedad), format(atom(Info), 'Trata Enfermedad: ~w', [Enfermedad]).
info_planta(Especie, Info) :- accion_efecto_planta(Especie, Efecto), format(atom(Info), 'Acci�n/Efecto: ~w', [Efecto]).
info_planta(Especie, Info) :- modo_tratamiento(Especie, Modo), format(atom(Info), 'Modo de Tratamiento: ~w', [Modo]).
info_planta(Especie, Info) :- precaucion_planta(Especie, Precaucion), format(atom(Info), 'Precauci�n: ~w', [Precaucion]).
info_planta(Especie, Info) :- sintoma_enfermedad(Enfermedad, Sintoma), trata_enfermedad(Especie, Enfermedad), format(atom(Info), 'S�ntoma Asociado: ~w (Enfermedad: ~w)', [Sintoma, Enfermedad]).

% Mapeo de texto a consulta
ejecutar_consulta_general(Opcion, Param, Text) :-
    (   consulta_resultado(Opcion, Param, Resultado) ->
        atomic_list_concat(['\n\n--- Resultado de la consulta: ', Opcion, ' ---\n', Resultado], Texto),
        send(Text, append, Texto)
    ;   send(Text, append, '\n\n[Error] No se pudo ejecutar la consulta.')
    ).

% Asociaci�n de nombres de men� a llamadas reales
consulta_resultado('Plantas medicinales', _, Resultado) :- plantas_medicinales(Resultado).
consulta_resultado('Elementos en plantas', _, Resultado) :- elementos_plantas(Resultado).
consulta_resultado('Elementos de una planta', Planta, Resultado) :- elementos_planta(Planta, Resultado).
consulta_resultado('Plantas que producen medicamentos', _, Resultado) :- plantas_producen_medicamentos(Resultado).
consulta_resultado('Medicamentos de una planta', Planta, Resultado) :- medicamentos_planta(Planta, Resultado).
consulta_resultado('Medicamentos de plantas', _, Resultado) :- medicamentos_de_plantas(Resultado).
consulta_resultado('Efectos de medicamentos de plantas', _, Resultado) :- efectos_medicamentos_plantas(Resultado).
consulta_resultado('Efectos de un medicamento', Med, Resultado) :- efectos_medicamento_especifico(Med, Resultado).
consulta_resultado('Acciones o efectos de plantas', _, Resultado) :- acciones_efectos_plantas(Resultado).
consulta_resultado('Significado de acci�n o efecto', Efecto, Resultado) :- significado_accion_efecto(Efecto, Resultado).
consulta_resultado('Plantas y sus acciones/efectos', _, Resultado) :- listado_plantas_acciones(Resultado).
consulta_resultado('Acciones de una planta', Planta, Resultado) :- acciones_planta(Planta, Resultado).
consulta_resultado('Plantas analg�sicas', _, Resultado) :- plantas_analgesicas(Resultado).
consulta_resultado('Plantas y nombres cient�ficos', _, Resultado) :- plantas_y_nombre_cientifico(Resultado).
consulta_resultado('Enfermedades tratadas por plantas', _, Resultado) :- enfermedades_curadas_plantas(Resultado).
consulta_resultado('Enfermedades tratadas por una planta', Planta, Resultado) :- enfermedades_planta(Planta, Resultado).
consulta_resultado('Plantas que tratan una enfermedad', Enfermedad, Resultado) :- plantas_curan_enfermedad(Enfermedad, Resultado).
consulta_resultado('Formas de preparaci�n', _, Resultado) :- formas_preparacion(Resultado).
consulta_resultado('Preparaci�n de una planta', Planta, Resultado) :- modos_preparacion_planta(Planta, Resultado).
consulta_resultado('Tratamiento para una enfermedad', Enfermedad, Resultado) :- tratamiento_enfermedad(Enfermedad, Resultado).
consulta_resultado('Origen de plantas', _, Resultado) :- origenes_plantas(Resultado).
consulta_resultado('Origen de una planta', Planta, Resultado) :- origen_planta(Planta, Resultado).
consulta_resultado('Tratamiento general para enfermedad', Enfermedad, Resultado) :- tratamiento_enfermedad_general(Enfermedad, Resultado).
consulta_resultado('Botiqu�n de plantas', _, Resultado) :- botiquin_plantas(Resultado).

% Iniciar autom�ticamente
:- initialization(mostrar_gui).
