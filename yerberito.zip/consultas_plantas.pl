:- use_module(bdplantas).

% Predicado auxiliar para unir listas con saltos de l�nea
join_with_newline([], '').
join_with_newline([H|T], Result) :-
    join_with_newline(T, Rest),
    (Rest = '' -> Result = H ; format(atom(Result), '~w\n~w', [H, Rest])).

% Predicado auxiliar para manejar listas vac�as
format_list([], 'No hay informaci�n disponible.').
format_list(List, Result) :-
    join_with_newline(List, Result).

% 1. �Cu�les son plantas o plantas medicinales?
plantas_medicinales(Result) :-
    findall(Planta, planta(Planta), Plantas),
    sort(Plantas, PlantasUnicas),
    format_list(PlantasUnicas, Result).

% 2. �Qu� elementos se encuentran en las plantas?
elementos_plantas(Result) :-
    findall(Elemento, elementos_planta(_, Elemento), ElementosList),
    flatten(ElementosList, AllElementos),
    sort(AllElementos, ElementosUnicos),
    format_list(ElementosUnicos, Result).

% 3. �Qu� elementos tiene una planta en espec�fica? Ejemplo: manzanilla
elementos_planta(Planta, Result) :-
    (   elementos_planta(Planta, Elementos) ->
        format_list(Elementos, Result)
    ;   format(atom(Result), 'No hay informaci�n sobre los elementos qu�micos de ~w.', [Planta])
    ).

% 4. �Qu� plantas producen medicamentos?
plantas_producen_medicamentos(Result) :-
    findall(Planta, produce_medicamento(Planta, _), Plantas),
    sort(Plantas, PlantasUnicas),
    format_list(PlantasUnicas, Result).

% 5. �Qu� medicamentos producen una planta en espec�fico?
medicamentos_planta(Planta, Result) :-
    findall(Medicamento, produce_medicamento(Planta, Medicamento), Medicamentos),
    sort(Medicamentos, MedicamentosUnicos),
    format_list(MedicamentosUnicos, Result).

% 6. �Qu� medicamentos provienen de plantas?
medicamentos_de_plantas(Result) :-
    findall(Medicamento, produce_medicamento(_, Medicamento), Medicamentos),
    sort(Medicamentos, MedicamentosUnicos),
    format_list(MedicamentosUnicos, Result).

% 7. �Cu�les son las acciones o efectos de medicamentos provenientes de plantas?
efectos_medicamentos_plantas(Result) :-
    findall(Efecto, efectos_medicamento(_, Efecto), EfectosList),
    flatten(EfectosList, AllEfectos),
    sort(AllEfectos, EfectosUnicos),
    format_list(EfectosUnicos, Result).

% 8. �Cu�les son los efectos o acciones de un medicamento en espec�fico?
efectos_medicamento_especifico(Medicamento, Result) :-
    (   efectos_medicamento(Medicamento, Efectos) ->
        format_list(Efectos, Result)
    ;   format(atom(Result), 'No hay informaci�n sobre el medicamento ~w.', [Medicamento])
    ).

% 9. �Cu�les son las acciones o efectos que tienen las plantas?
acciones_efectos_plantas(Result) :-
    findall(Efecto, accion_efecto_planta(_, Efecto), Efectos),
    sort(Efectos, EfectosUnicos),
    format_list(EfectosUnicos, Result).

% 10. Significado de palabras que son acciones o efectos de plantas sobre organismo
significado_accion_efecto(Efecto, Result) :-
    (   definicion_accion_efecto(Efecto, Definicion) ->
        format(atom(Result), '~w: ~w', [Efecto, Definicion])
    ;   format(atom(Result), 'No hay definici�n disponible para ~w.', [Efecto])
    ).

% Definiciones de acciones/efectos (ampliadas)
definicion_accion_efecto(analgesico, 'Reduce o alivia el dolor.').
definicion_accion_efecto(antiinflamatorio, 'Disminuye la inflamaci�n en tejidos.').
definicion_accion_efecto(antiparasitario, 'Elimina o controla par�sitos.').
definicion_accion_efecto(diuretico, 'Aumenta la producci�n y eliminaci�n de orina.').
definicion_accion_efecto(expectorante, 'Facilita la expulsi�n de mucosidad de las v�as respiratorias.').
definicion_accion_efecto(sedante, 'Induce relajaci�n o sue�o.').
definicion_accion_efecto(digestivo, 'Mejora la digesti�n o alivia problemas digestivos.').
definicion_accion_efecto(antiespasmodico, 'Reduce espasmos musculares o contracciones.').
definicion_accion_efecto(hipoglucemiante, 'Reduce los niveles de glucosa en sangre.').
definicion_accion_efecto(hipotensor, 'Disminuye la presi�n arterial.').
definicion_accion_efecto(emenagogo, 'Promueve el flujo menstrual.').
definicion_accion_efecto(cardiotonico, 'Fortalece la funci�n card�aca.').
definicion_accion_efecto(cicatrizante, 'Promueve la curaci�n de heridas y regeneraci�n de tejidos.').
definicion_accion_efecto(antipiretico, 'Reduce la fiebre.').
definicion_accion_efecto(antimalarico, 'Combate infecciones por malaria.').
definicion_accion_efecto(antitusivo, 'Alivia o suprime la tos.').

% 11. Listado de plantas y sus acciones o efectos sobre el organismo
listado_plantas_acciones(Result) :-
    findall(Planta-Efecto, accion_efecto_planta(Planta, Efecto), Pares),
    sort(Pares, ParesUnicos),
    findall(Linea, (member(Planta-Efecto, ParesUnicos), format(atom(Linea), '~w: ~w', [Planta, Efecto])), Lineas),
    format_list(Lineas, Result).

% 12. Acciones o efectos de una planta en espec�fico
acciones_planta(Planta, Result) :-
    findall(Efecto, accion_efecto_planta(Planta, Efecto), Efectos),
    sort(Efectos, EfectosUnicos),
    format_list(EfectosUnicos, Result).

% 13. �Qu� plantas son analg�sicas?
plantas_analgesicas(Result) :-
    findall(Planta, accion_efecto_planta(Planta, analgesico), Plantas),
    sort(Plantas, PlantasUnicas),
    format_list(PlantasUnicas, Result).

% 14. Listar plantas medicinales y su nombre cient�fico
plantas_y_nombre_cientifico(Result) :-
    findall(Planta-Nombre, nombre_cientifico(Planta, Nombre), Pares),
    sort(Pares, ParesUnicos),
    findall(Linea, (member(Planta-Nombre, ParesUnicos), format(atom(Linea), '~w: ~w', [Planta, Nombre])), Lineas),
    format_list(Lineas, Result).

% 15. �Cu�les son las enfermedades que curan las plantas?
enfermedades_curadas_plantas(Result) :-
    findall(Enfermedad, trata_enfermedad(_, Enfermedad), Enfermedades),
    sort(Enfermedades, EnfermedadesUnicas),
    format_list(EnfermedadesUnicas, Result).

% 16. �Cu�les son las enfermedades que cura una planta en espec�fico? Ejemplo: zabila
enfermedades_planta(Planta, Result) :-
    findall(Enfermedad, trata_enfermedad(Planta, Enfermedad), Enfermedades),
    sort(Enfermedades, EnfermedadesUnicas),
    format_list(EnfermedadesUnicas, Result).

% 17. �Cu�les son las plantas que curan una enfermedad? Ejemplo: herpes
plantas_curan_enfermedad(Enfermedad, Result) :-
    findall(Planta, trata_enfermedad(Planta, Enfermedad), Plantas),
    sort(Plantas, PlantasUnicas),
    format_list(PlantasUnicas, Result).

% 18. �Cu�les son las formas de preparaci�n para tratamiento de enfermedades con uso de plantas?
formas_preparacion(Result) :-
    findall(Preparacion, modo_preparacion(_, Preparacion), Preparaciones),
    sort(Preparaciones, PreparacionesUnicas),
    format_list(PreparacionesUnicas, Result).

% 19. �Cu�les son los modos de preparaci�n de una planta en espec�fico?
modos_preparacion_planta(Planta, Result) :-
    findall(Preparacion, modo_preparacion(Planta, Preparacion), Preparaciones),
    sort(Preparaciones, PreparacionesUnicas),
    format_list(PreparacionesUnicas, Result).

% 20. �Cu�l es el tratamiento y su preparaci�n para alguna enfermedad?
tratamiento_enfermedad(Enfermedad, Result) :-
    findall(Planta-Preparacion-Tratamiento,
            (trata_enfermedad(Planta, Enfermedad),
             modo_preparacion(Planta, Preparacion),
             modo_tratamiento(Planta, Tratamiento)),
            Trios),
    sort(Trios, TriosUnicos),
    findall(Linea,
            (member(Planta-Preparacion-Tratamiento, TriosUnicos),
             format(atom(Linea), 'Planta: ~w, Preparaci�n: ~w, Tratamiento: ~w', [Planta, Preparacion, Tratamiento])),
            Lineas),
    format_list(Lineas, Result).

% 21. �Cu�les son los or�genes de las plantas medicinales?
origenes_plantas(Result) :-
    findall(Continente-Pais,
            (continente_origen(Planta, Continente), pais_origen(Planta, Pais)),
            Pares),
    sort(Pares, ParesUnicos),
    findall(Linea,
            (member(Continente-Pais, ParesUnicos),
             format(atom(Linea), 'Continente: ~w, Pa�s: ~w', [Continente, Pais])),
            Lineas),
    format_list(Lineas, Result).

% 22. �Cu�l es el origen de una planta?
origen_planta(Planta, Result) :-
    findall(Continente-Pais,
            (continente_origen(Planta, Continente), pais_origen(Planta, Pais)),
            Pares),
    sort(Pares, ParesUnicos),
    findall(Linea,
            (member(Continente-Pais, ParesUnicos),
             format(atom(Linea), 'Continente: ~w, Pa�s: ~w', [Continente, Pais])),
            Lineas),
    format_list(Lineas, Result).

% 23. �Cu�l es el tratamiento para una enfermedad (ya sea con plantas o medicamentos)?
tratamiento_enfermedad_general(Enfermedad, Result) :-
    tratamiento_enfermedad(Enfermedad, PlantasResult),
    findall(Tratamiento, tratamiento_medicamento(Enfermedad, Tratamiento), Tratamientos),
    format_list(Tratamientos, MedicamentosResult),
    (   PlantasResult = 'No hay informaci�n disponible.', MedicamentosResult = 'No hay informaci�n disponible.' ->
        Result = 'La base de conocimientos no contiene tratamientos para esta enfermedad.'
    ;   format(atom(Result), 'Tratamientos con plantas:\n~w\nTratamientos con medicamentos:\n~w', [PlantasResult, MedicamentosResult])
    ).

% 24. Botiqu�n de plantas
botiquin_plantas(Result) :-
    % Selecci�n de plantas vers�tiles, incluyendo sabila
    Botiquin = [manzanilla, lavanda, eucalipto, llanten, sabila],
    findall(Linea,
            (member(Planta, Botiquin),
             nombre_cientifico(Planta, Nombre),
             findall(Enfermedad, trata_enfermedad(Planta, Enfermedad), Enfermedades),
             sort(Enfermedades, EnfermedadesUnicas),
             atomic_list_concat(EnfermedadesUnicas, ', ', EnfermedadesStr),
             format(atom(Linea), '~w (~w): ~w', [Planta, Nombre, EnfermedadesStr])),
            Lineas),
    format_list(Lineas, Result).
